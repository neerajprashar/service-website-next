"use client";
import { useState } from "react";
import Link from "next/link";

const Header = () => {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
 
      <nav className="navbar navbar-expand-lg navbar-light px-4">
        <Link href="/" className="navbar-brand fw-bold">
          <img src="/logo.png" alt="WebOps Logo" />
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link href="/" className="nav-link">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/about" className="nav-link">
                About Us
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/services" className="nav-link">
                Services
              </Link>
            </li>
            <li className="nav-item">
              <Link href="/contact" className="nav-link">
                Contact
              </Link>
            </li>
          </ul>
          <button
            className="btn btn-primary ms-3"
            onClick={() => setShowModal(true)}
          >
            Book Now
          </button>
        </div>
      </nav>

      {/* Booking Modal */}
      {showModal && (
        <div className="modal d-block" tabIndex="-1">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Book a Service</h5>
                <button className="btn-close" onClick={() => setShowModal(false)}></button>
              </div>
              <div className="modal-body">
                <form>
                  <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input type="text" className="form-control" required />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Phone</label>
                    <input type="text" className="form-control" required />
                  </div>
                  <div className="mb-3">
                    <label className="form-label">Service Needed</label>
                    <select className="form-select">
                      <option>Plumbing</option>
                      <option>Electrician</option>
                      <option>Landscaping</option>
                    </select>
                  </div>
                  <button type="submit" className="btn btn-primary w-100">
                    Submit Request
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Background */}
      {showModal && <div className="modal-backdrop fade show" onClick={() => setShowModal(false)}></div>}
    </>
  );
};

export default Header;
