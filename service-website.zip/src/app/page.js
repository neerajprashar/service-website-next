import Image from "next/image";
import styles from "./page.module.css";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import WhyChooseUs from "@/components/WhyChooseUs";
import OurServices from "@/components/OurServices";


export default function Home() {
  return (
    <>
    <header className="bg-light">
      <div className="container">
        <Header />
      </div>
    </header>
    <main>
      <div className="container-fluid px-0">
        <Hero />
      </div>
      <section className="why-choose-us py-5 bg-light text-center">
        <WhyChooseUs />
      </section>
      <section className="our-services py-5 text-center">
        <OurServices />
      </section>
    </main>
    </>
 
  );
}
