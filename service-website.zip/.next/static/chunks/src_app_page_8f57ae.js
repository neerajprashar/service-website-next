(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_8f57ae.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_8f57ae.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_18cdd4._.js",
    "static/chunks/src_de26f8._.js",
    "static/chunks/src_app_page_module_d12eb7.css"
  ],
  "source": "dynamic"
});
